const AWS = require('aws-sdk');
const s3 = new AWS.S3();
const dynamoDB = new AWS.DynamoDB.DocumentClient();
const { v4: uuidv4 } = require('uuid');

const BUCKET_NAME = process.env.BUCKET_NAME || 'my-beats-store-bucket';

exports.handler = async (event) => {
    try {
        const formData = JSON.parse(event.body);
        const { beatName, price, beatFile } = formData;

        const beatId = uuidv4();
        const fileKey = `beats/${beatId}-${beatName}.mp3`;

        // Upload to S3
        const s3Params = {
            Bucket: BUCKET_NAME,
            Key: fileKey,
            Body: Buffer.from(beatFile, 'base64'),
            ContentType: 'audio/mpeg',
        };
        await s3.putObject(s3Params).promise();

        // Save Metadata to DynamoDB
        const dbParams = {
            TableName: 'BeatsMetadata',
            Item: {
                id: beatId,
                name: beatName,
                price: parseFloat(price),
                filePath: fileKey,
                uploadedAt: new Date().toISOString()
            }
        };
        await dynamoDB.put(dbParams).promise();

        return {
            statusCode: 200,
            body: JSON.stringify({ message: 'Beat uploaded successfully!' })
        };
    } catch (error) {
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Error uploading beat', error })
        };
    }
};
